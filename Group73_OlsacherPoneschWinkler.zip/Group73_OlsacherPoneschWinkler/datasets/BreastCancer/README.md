## 184.702 TU ML 2025W - Breast Cancer

### Goal
Predict if a patient has "recurrence-events" or "no-recurrence-events"

### Kaggle Link
https://www.kaggle.com/competitions/184-702-tu-ml-2025w-breast-cancer/data

### File descriptions
- *.lrn.csv - the training set
- *.tes.csv - the test set
- *.sol.ex.csv - a *sample* solution file in the correct format