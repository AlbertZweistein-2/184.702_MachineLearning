## 184.702 TU ML 2025W - Loan

### Goal
Predict the score of a loan application

### Kaggle Link
https://www.kaggle.com/competitions/184-702-tu-ml-2025-w-loan/data


### File descriptions

*.lrn.csv - the training set
*.tes.csv - the test set
*.sol.ex.csv - a **SAMPLE** solution file in the correct format